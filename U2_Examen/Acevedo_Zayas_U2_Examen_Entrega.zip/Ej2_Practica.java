package com.company;

import java.util.Scanner;

public class Ej2_Practica {
    public static void main(String[] args) {

        //Realizar un programa que dado un número que se solicita la usuario por
        // consola eliminará de ese número todos los 0 y todos los 8 indicando
        // adicionalmente cuántos números ha eliminado.Deberá solicitar el número mientras que
        //el número introducido no sea positivo.

        Scanner sc = new Scanner(System.in);
        int num;

        System.out.println("Escribe un número");
        num= sc.nextInt();

        while (num<0){

            System.out.println("Número introducido incorrecto. Introduzca un número positivo");
            num= sc.nextInt();






        }



    }
}
