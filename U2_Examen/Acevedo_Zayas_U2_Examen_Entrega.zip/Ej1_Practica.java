package com.company;

import java.util.Scanner;

public class Ej1_Practica {
    public static void main(String[] args) {

        //Escribe un programa que pinte por pantalla un par de calcetines,
        // de los que se ponen al lado del árbol de Navidad para que Papá Noel deje sus regalos.
        //El usuario debe introducir la altura. Suponemos que el usuario introduce una altura mayor o igual a 4.
        // Observa que la talla de los calcetines y la distancia
        //que hay entre ellos (dos espacios) no cambia, lo único que varía es la altura.

        int altura;
        Scanner sc=new Scanner(System.in);

        System.out.println("Introduce la altura de los calcetines");
        altura= sc.nextInt();

        for (int i =0 ; i<altura ; i++) {
            if (i<altura-1) {
                System.out.println("*** ***");

            } else {
                for (int j = 0 ; j <altura/2+1 ; j++) {
                    System.out.print("* *");

                }
            }


            

                
            





        }

}}
