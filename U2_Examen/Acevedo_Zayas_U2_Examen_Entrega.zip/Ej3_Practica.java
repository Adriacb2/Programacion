package com.company;

import java.util.Scanner;

public class Ej3_Practica {
    public static void main(String[] args) {


        //Ahora que se acerca la notería de Navidad queremos saber si un número
        // va a proporcionar suerte a un usuario.

        // Solicitaremos a un usuario cuáles son sus 3 números favoritos
        // y para calcular  si un número le va a dar suerte dicho número tendrá más ocurrencias
        // de esos números que de los demás.


        Scanner sc = new Scanner(System.in);
        int n1,n2,n3;
        String loteria;

        System.out.println("Introduce tu primer número de la suerte");
        n1= sc.nextInt();
        System.out.println("Introduce el segundo número");
        n2= sc.nextInt();
        System.out.println("Introduce el tercer y último número");
        n3= sc.nextInt();

        System.out.println("Introduce el número de la lotería");
        loteria= sc.next();

        System.out.println(loteria.indexOf(n1+n2+n3));


    }
}
