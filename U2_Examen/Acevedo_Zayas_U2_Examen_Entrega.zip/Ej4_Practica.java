package com.company;

import java.util.Scanner;

public class Ej4_Practica {
    public static void main(String[] args) {

        //Escribir un programa que incremente la hora de un reloj tantos segundos como le solicitemos
        // mostrando cada vez la hora nueva.

        //Se solicitará al usuario por teclado las horas, los minutos y los segundos y
        // el número de segundos que se quiere aumentar la hora.
        //Supondremos que el usuario siempre introduce valores correctos.

        Scanner sc = new Scanner(System.in);
        int h,min,seg,seg2;

        System.out.println("Introduce las horas");
        h= sc.nextInt();
        System.out.println("Introduce los minutos");
        min= sc.nextInt();
        System.out.println("Introduce los segundos");
        seg= sc.nextInt();

        System.out.println("Introduce los segundos a incrementar");
        seg2= sc.nextInt();

        System.out.println("Aumentando la hora...");

        System.out.print(h+":");
        System.out.print(min+":");
        System.out.print(seg);


        }

        }
